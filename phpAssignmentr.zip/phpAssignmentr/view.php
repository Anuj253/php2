<?php
include("connection.php");

$database = new Db_connection();
$res = $database->read();

// Delete record from table
if (isset($_GET['deleteId']) && !empty($_GET['deleteId'])) {
  $deleteId = $_GET['deleteId'];
  $database->delete($deleteId);
}

?>

<!DOCTYPE html>
<html lang="en-US">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Subscriber Portal - View</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <div class="container">
      <h1 class="logo">Subscriber Portal - View</h1>
      <?php include("global_header.php"); ?>
    </div>
  </header>
  <main>
    <div class="container">
      <h2>Subscriber List</h2>
      <!-- Add the "Add" button -->
      <div class="add-button">
        <a class="button is-primary" href="add.php">Add</a>
      </div>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Interests</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Country</th>
            <th>Edit</th> <!-- New column for "Edit" button -->
            <th>Delete</th> <!-- New column for "Delete" button -->
          </tr>
        </thead>
        <tbody>
          <?php
          if ($res && mysqli_num_rows($res) > 0) {
            while ($row = mysqli_fetch_assoc($res)) {
              echo "<tr>";
              echo "<td>" . $row['id'] . "</td>";
              echo "<td>" . $row['name'] . "</td>";
              echo "<td>" . $row['email'] . "</td>";
              echo "<td>" . $row['interests'] . "</td>";
              echo "<td>" . $row['age'] . "</td>";
              echo "<td>" . $row['gender'] . "</td>";
              echo "<td>" . $row['country'] . "</td>";
              // Add the "Edit" button with a link to the edit page
              echo "<td><a class='button is-primary' href='edit.php?editId=" . $row['id'] . "'>Edit</a></td>";
              // Add the "Delete" button with a link to delete the record
              echo "<td><a class='button is-danger' href='view.php?deleteId=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this record?\")'>Delete</a></td>";
              echo "</tr>";
            }
          } else {
            echo "<tr><td colspan='9'>No subscribers found.</td></tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
  </main>
  <footer>
    <p>@Anuj 2023 Subscriber Portal. All rights reserved.</p>
  </footer>
</body>
</html>

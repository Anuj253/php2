<nav>
        <ul class="menu">
          <li><a href="index.php">Home</a></li>
          <li><a href="https://georgianatilac.com/our-people/">About Us</a></li>
         
          <li class="dropdown">
            <a href="#">Apply</a>
            <ul class="dropdown-menu">
              <li><a href="Online Courses with Certificates - Grow with Google
grow.google
https://www.grow.google">Online</a></li>
              <li><a href="https://www.googleadservices.com/pagead/aclk?sa=L&ai=DChcSEwikzYzG1cr_AhUd_eMHHYybBOEYABAAGgJ5bQ&ohost=www.google.com&cid=CAESaeD2hr9Oy-Rd_mPAhCaEW03vSGRUa-Lx5BAXmtUINW_doCu7Bf7nfooZ3Kj7m_eCcPWm04Xtw18D6TB37zLxprSXPI3hDYBAzqvw4iGDVY4jEagoWyvNUhhq7bTqkt0PmF1Rzb-FIRnq4A&sig=AOD64_3CxdyvrUKGqyf8VdWs75PzqliDSQ&q&adurl&ved=2ahUKEwikp4bG1cr_AhVShIkEHXhjDL4Q0Qx6BAgHEAE">Interview</a></li>
              
            </ul>
          </li>
          <li><a href="https://georgianatilac.com/contact/">Contact</a></li>
        </ul>
      </nav>
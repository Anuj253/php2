<?php
include("connection.php");

$database = new Db_connection();

// Check if the form is submitted for updating record
if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $interests = $_POST['interests'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $country = $_POST['country'];

    // Update record in the database
    $database->update($id, $name, $email, $interests, $age, $gender, $country);

    // Redirect back to view.php after updating record
    header("Location: view.php?msg2=update");
    exit();
}

// Get the ID of the record to edit
if (isset($_GET['editId'])) {
    $editId = $_GET['editId'];
    $result = $database->read($editId);

    if ($result && mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
    } else {
        // Redirect to view.php if record not found
        header("Location: view.php");
        exit();
    }
} else {
    // Redirect to view.php if editId is not provided
    header("Location: view.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en-US">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Subscriber Portal - Edit Subscriber</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <div class="container">
      <h1 class="logo">Subscriber Portal - Edit Subscriber</h1>
      <?php include("global_header.php"); ?>
    </div>
  </header>
  <main>
    <div class="container">
      <h2>Edit Subscriber</h2>
      <form action="edit.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <div class="field">
          <label class="label">Name:</label>
          <div class="control">
            <input type="text" class="input" name="name" value="<?php echo $row['name']; ?>" required="">
          </div>
        </div>
        <div class="field">
          <label class="label">Email:</label>
          <div class="control">
            <input type="email" class="input" name="email" value="<?php echo $row['email']; ?>" required="">
          </div>
        </div>
        <div class="field">
          <label class="label">Interests:</label>
          <div class="control">
            <input type="text" class="input" name="interests" value="<?php echo $row['interests']; ?>">
          </div>
        </div>
        <div class="field">
          <label class="label">Age:</label>
          <div class="control">
            <input type="number" class="input" name="age" value="<?php echo $row['age']; ?>">
          </div>
        </div>
        <div class="field">
          <label class="label">Gender:</label>
          <div class="control">
            <input type="text" class="input" name="gender" value="<?php echo $row['gender']; ?>">
          </div>
        </div>
        <div class="field">
          <label class="label">Country:</label>
          <div class="control">
            <input type="text" class="input" name="country" value="<?php echo $row['country']; ?>">
          </div>
        </div>
        <div class="field is-grouped">
          <div class="control">
            <input type="submit" name="submit" class="button is-primary" value="Update">
          </div>
        </div>
      </form>
    </div>
  </main>
  <footer>
    <p>@Anuj 2023 Subscriber Portal. All rights reserved.</p>
  </footer>
</body>
</html>
